function hymod2
% hymod2: Standalone script for running the hydrologic model HYMOD2.

% Date: Feb 14, 2017
% Contact Person: Tirthankar Roy (royt@email.arizona.edu)
% Copyright: Hoshin V Gupta and Tirthankar Roy (University of Arizona)

% Reference:
%   Roy, T., H.V. Gupta, A. Serrat-Capdevila, and J.B. Valdes (2017), 
%   Using satellite-based evapotranspiration estimates to improve the 
%   structure of a simple conceptual rainfall-runoff model, Hydrology 
%   and Earth System Sciences, 21(2), 879�896, doi:10.5194/hess-21-879-2017

% Disclaimer:
%   This program comes 'as is' and the authors cannot be held responsible
%   for any issues resulting from the improper functioning of the program. 
%   If found, please report the bugs to royt@email.arizona.edu. Prompt
%   action will be taken to fix reported bugs.

% Description:
%   Data   : Struct storing all observed values.
%   Model  : Struct storing all simulated values.
%   PP     : Precipitation.
%   QQ     : Discharge.
%   PE     : Potential evapotranspiration.
%   ET     : Actual evapotranspiration.
%   IOData : Example input file with variables organized as [PP, PE, QQ].
%            Input file size: number of datapoints * numder of variables.

% Clear workspace and command window, close figure windows
clear all; close all; clc

% Load data, assign variables
Data = LoadData;

% Set prior parameters and states
Prior = PriorHyModV2;

% Run the model
Model = SimHyMod(Data,Prior);

% Create plots
CreatePlots(Data,Model)

% Calculate error statistics
Errors = ErrorStat(Data.QQ,Model.QQ);

% Save results
Results.Data   = Data;
Results.Model  = Model;
Results.Prior  = Prior;
Results.Errors = Errors;
save Results Results

end

function Data = LoadData
% LoadData: Function for loading data.
% Change the input file name as necessary.

load Inputs                   % Example input file
Data.PP    = Inputs(:,1);     % Precip   
Data.PE    = Inputs(:,2);     % PET 
Data.QQ    = Inputs(:,3);     % Discharge
Data.NDays = length(Data.PP); % Simulation period

end

function Prior = PriorHyModV2
% PriorHyModV2: Function for loading the parameters and initial states.
% Change the parameter values as necessary.

% Assign parameter values
Huz  = 500;   % Height of soil moisture accounting tank
B    = 1;     % Distribution function shape parameter
Alp  = 0.2;   % Quick-slow split parameter
Nq   = 2;     % Number of quickflow routing tanks
Ks   = 0.01;  % Slow flow routing tanks rate parameter
Kq   = 0.3;   % Quick flow routing tanks rate parameter
Kmax = 0.5;   % Upper limit of ET resistance parameter
G    = 0.2;   % Parameter for deriving lower limit of ET resistance parameter
CE   = 1;     % Exponent on ratio of actual and maximum storage capacities

% Pack parameter values in 'Par'
Par(1,:) = Huz;   Par(2,:)  = B;   Par(3,:)  = Alp;
Par(4,:) = Nq;    Par(5,:)  = Ks;  Par(6,:)  = Kq;
Par(7,:) = Kmax;  Par(8,:)  = G;   Par(9,:)  = CE;

% Initial states
XCuz = 0;           % Soil moisture storage      
Xq   = zeros(1,ceil(Nq)); % Quickflow tank(s) storage
Xs   = 0;           % Slowflow tank storage

% Assign names to the parameters and initial states
ParName  = ['Par Huz';'Par B  ';'Par Alp';'Par Nq ';'Par Ks ';'Par Kq ';'Par K  ';'Par G  ';'Par CE '];
SttName  = ['State XCuz';'State Xq  ';'State Xs  '];

% Pack variables
InState.XCuz  = XCuz;
InState.Xq    = Xq;
InState.Xs    = Xs;
Prior.Par     = Par;
Prior.InState = InState;
Prior.ParName = ParName;
Prior.SttName = SttName;
    
end

function Model = SimHyMod(Data,Prior)
% SimHyMod: Function initiating the time loop.

% Unpack required parameters
Hpar = Prior.Par(1); 
Bpar = Prior.Par(2);
Ks   = Prior.Par(5); 
Kq   = Prior.Par(6);
Nq   = max(round(Prior.Par(4)),1);
    
% Unpack initial states
InXCuz = Prior.InState.XCuz;
InXq   = Prior.InState.Xq;
InXs   = Prior.InState.Xs;

% Model reparameterization
b    = log((1-Bpar/2))/log(0.5);
Cpar = Hpar/(1+b);  
    
% Prepare time loop variables
XCAft         = min(max(InXCuz,0),Cpar);                % Soil moisture accounting tank
XHAft         = Hpar*(1-power((1-XCAft/Cpar),1/(1+b))); % Initial corresponding height
XqAft(1:Nq,1) = max(InXq(1:Nq),0);                      % Quickflow routing tank 
XsAft         = max(InXs,0);                            % Slowflow routing tank

% Time loop
for t = 1:Data.NDays
    
    % Initialize the state variables for the time step
    XHBef         = XHAft;
    XCBef         = XCAft;
    XsBef         = XsAft; 
    XqBef(1:Nq,1) = XqAft(1:Nq,1);
    
    % Compute output observation & prediction (before processing data)
    PQs = Ks*XsBef;
    PQq = Kq*XqBef(Nq,1);
    PQQ = PQs + PQq;    
    
    % Pack variables into the 'Model' structure
    Model.PQQ(t,1)       = PQQ;                 
    Model.XHIn(t,1)      = XHBef;
    Model.XCIn(t,1)      = XCBef;
    Model.XsIn(t,1)      = XsBef;
    Model.XqIn(t,1:Nq,1) = XqBef(1:Nq,1);

    % Run model
    Model = SimHyModV2(Data,Model,Prior,t); 

    % Unpack the new state variables after tunning model        
    XHAft         = Model.XHOut(t,1);  
    XCAft         = Model.XCOut(t,1);
    XsAft         = Model.XsOut(t,1);  
    XqAft(1:Nq,:) = Model.XqOut(t,1:Nq,1);

end
end

function Model = SimHyModV2(Data,Model,Prior,t)
% SimHyModV2: Function for running soil moisture and routing components.

% Initialize simulation variables, data & parameters
PPDay  = Data.PP(t);  % Precipitation flux
PETDay = Data.PE(t);  % PET flux  

% Initialize parameters
Hpar  = Prior.Par(1); 
Bpar  = Prior.Par(2); 
Alp   = Prior.Par(3); 
Ks    = Prior.Par(5); 
Kq    = Prior.Par(6);
Nq    = max(round(Prior.Par(4)),1);
Kmax  = Prior.Par(7);
Gpar  = Prior.Par(8);
CEpar = Prior.Par(9);

% Model reparameterization     
b    = log((1-Bpar/2))/log(0.5);
Cpar = Hpar/(1+b);  
    
% Unpack state variables at begining of calculation 
XHIn         = Model.XHIn(t,1);  
XCIn         = Model.XCIn(t,1);
XsIn         = Model.XsIn(t,1); 
XqIn(1:Nq,1) = Model.XqIn(t,1:Nq,1);

% Run Model computations for the time step 
MPP = max(PPDay,0); 
MPE = max(PETDay,0);
    
% Run ModPdm soil moisture accounting including ET
[OV, MET, XHOut, XCOut, XCInt] = ModPdmV2(Hpar, Bpar, XHIn, MPP, MPE, Kmax, Gpar, CEpar);
      
XCOut = min( max( XCOut(1), 0), Cpar );             
XHOut = Hpar*( 1 - power((1-XCOut/Cpar),1/(1+b)) ); 
      
% Run Nash Cascade routing of quickflow
[Qq, XqOut(1:Nq,1)] = ModNash(Kq, Nq, XqIn(1:Nq,1), Alp*OV);
XqOut(1:Nq,1)       = max( XqOut(1:Nq,1), 0 );
    
% Run infinite linear tank (Nash Cascade with N=1) routing of slowflow
[Qs, XsOut] = ModNash(Ks, 1, XsIn, (1-Alp)*OV);
XsOut       = max( XsOut, 0 ); 
    
% Compute total model outflow
MQQ = Qq + Qs;

% Pack model arrays
Model.PP(t,1)    = MPP;      
Model.PE(t,1)    = MPE;       
Model.Qs(t,1)    = Qs;        
Model.OV(t,1)    = OV;
Model.QQ(t,1)    = MQQ;
Model.ET(t,1)    = MET;
Model.Qq(t,1)    = Qq;
Model.XHOut(t,1) = XHOut; 
Model.XsOut(t,1) = XsOut; 
Model.XCInt(t,1) = XCInt;
Model.XCOut(t,1) = XCOut;
Model.XqOut(t,1:Nq,1) = XqOut(1:Nq,1); 

end

function [OV,ET,Hend,Cend,Cint] = ModPdmV2(Hpar,Bpar,Hbeg,PP,PET,Kmax,Gpar,CEpar)
% ModPdmV2: Function for runing the soil moisture accounting module.

% Initialize variables
OV = []; ET = [];
    
% Convert from scaled CE (0-2) to unscaled ce (0 - Inf)
if CEpar < 0; error('CEpar parameter < 0'); end
if CEpar > 2; error('CEpar parameter > 2'); end
if CEpar == 2; ce = 10^6; else ce = log(1-CEpar/2)/log(0.5); end 
    
% Convert from scaled B (0-2) to unscaled b (0 - Inf)
if Bpar < 0; error('B parameter < 0'); end
if Bpar > 2; error('B parameter > 2'); end
if Bpar == 2; b = 10^6; else b = log(1-(Bpar/2))/log(0.5); end

% Compute maximum capacity of soil zone
Cpar = Hpar/(1+b); 
    
% Execute model for one time step
Cbeg  = Cpar*(1-power((1-(Hbeg/Hpar)),(1+b)));  % Contents at begining
OV2   = max(0,PP+Hbeg-Hpar);                    % Compute OV2 if enough PP
PPinf = PP-OV2;                                 % PP that does not go to OV2
Hint  = min(Hpar,(PPinf+Hbeg));                 % Intermediate height
Cint  = Cpar*(1-power((1-(Hint/Hpar)),(1+b)));  % Intermediate contents
OV1   = max(0, PPinf + Cbeg - Cint);            % Compute OV1
OV    = OV1 + OV2;                              % Compute total OV
    
% ET component
Kmin = Gpar*Kmax;
K = Kmin + (Kmax-Kmin)*(Cint/Cpar)^ce;
ET = K*min(PET,Cint);

% Final height corresponding to SMA contents
Cend = Cint - ET;                                 
Hend = Hpar*(1-power((1-Cend/Cpar),1/(1+b)));
    
end

function [Out,Xend] = ModNash(K,N,Xbeg,Inp)
% ModNash: Function for running the Nash Cascade for routing

% Initialize outflow
Out = []; 

% Computations
for Res = 1:N
    OO(Res)   = K*Xbeg(Res);
    Xend(Res) = Xbeg(Res) - OO(Res);
    if Res == 1; Xend(Res) = Xend(Res) + Inp; 
    else         Xend(Res) = Xend(Res) + OO(Res-1); end
end
Out = OO(N);
end

function CreatePlots(Data,Model)
% CreatePlots: Function for generating time series and scatter plots.
 
PP     = Data.PP;
DQQ    = Data.QQ;
MQQ    = Model.QQ;
NDays  = Data.NDays;

% Time series plot
figure; subplot(2,1,1); bar(PP);
axis([1 NDays 0 1.1*max(PP)]); axis ij; box on; grid on
ylabel('Precip','fontweight','bold'); title('Title','fontweight','bold');
        
subplot(2,1,2); plot(DQQ,'r.','markersize',4); hold on
plot(MQQ,'k','linewidth',1); hold off; legend('Observed','Simulated')
axis([1 NDays 0 1.1*max(max([DQQ MQQ]))]); box on; grid on
ylabel('Discharge','fontweight','bold'); xlabel('Days','fontweight','bold') 

% Scatter plot
Min = min([min(MQQ) min(DQQ)]); Max = max([max(MQQ) max(DQQ)]);
figure; scatter(MQQ,DQQ,10,'filled'); hold on
plot([Min Max],[Min Max],'k--','linewidth',1.5); hold off
legend('Data Points','45^{o} Line')
axis([Min Max Min Max]); axis square; box on
xlabel('Simulated','fontweight','bold'); ylabel('Observed','fontweight','bold') 

end

function Errors = ErrorStat(obs,sim)
% ErrorStat: Function for calculating the common error statistics.

% Remove NaNs
nanind = find(isnan(obs) == 1); obs(nanind) = []; sim(nanind) = [];
nanind = find(isnan(sim) == 1); obs(nanind) = []; sim(nanind) = [];

% Mean Squared Error
Errors.MSE = mean((sim-obs).^2);

% Nash-Sutcliffe Coefficient of Efficiency
Errors.NSE = 1-sum((sim-obs).^2)/sum((obs-mean(obs)).^2);

% Correlation Coefficient
C = corrcoef([sim,obs]); Errors.R = C(2,1); 
 
% Percentage Bias Error
Errors.PBE = sum(sim-obs)/sum(obs)*100;

end